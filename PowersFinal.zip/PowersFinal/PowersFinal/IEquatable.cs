﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowersFinal
{
    public interface IEquatable
    {
        //Question 1
        bool MyEquals(object other);
    }
}
