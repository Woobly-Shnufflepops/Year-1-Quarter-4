﻿namespace Vehical_Tester_Powers
{
    partial class frmVehicalTester
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtVehicalList = new System.Windows.Forms.RichTextBox();
            this.btnDisplayPeopleAndCars = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtPersonIndex = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMake = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtVin = new System.Windows.Forms.TextBox();
            this.btnAddACar = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtVinPriceUpdate = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPriceUpdate = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnUpdatePrice = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.txtVinSellCar = new System.Windows.Forms.TextBox();
            this.btnSellCar = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // rchtxtVehicalList
            // 
            this.rchtxtVehicalList.Location = new System.Drawing.Point(13, 13);
            this.rchtxtVehicalList.Name = "rchtxtVehicalList";
            this.rchtxtVehicalList.Size = new System.Drawing.Size(568, 184);
            this.rchtxtVehicalList.TabIndex = 0;
            this.rchtxtVehicalList.Text = "";
            // 
            // btnDisplayPeopleAndCars
            // 
            this.btnDisplayPeopleAndCars.Location = new System.Drawing.Point(413, 203);
            this.btnDisplayPeopleAndCars.Name = "btnDisplayPeopleAndCars";
            this.btnDisplayPeopleAndCars.Size = new System.Drawing.Size(168, 39);
            this.btnDisplayPeopleAndCars.TabIndex = 1;
            this.btnDisplayPeopleAndCars.Text = "Display People and Cars";
            this.btnDisplayPeopleAndCars.UseVisualStyleBackColor = true;
            this.btnDisplayPeopleAndCars.Click += new System.EventHandler(this.btnDisplayPeopleAndCars_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnAddACar);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtVin);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtPrice);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtYear);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtModel);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtMake);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtPersonIndex);
            this.panel1.Location = new System.Drawing.Point(13, 203);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(240, 200);
            this.panel1.TabIndex = 2;
            // 
            // txtPersonIndex
            // 
            this.txtPersonIndex.Location = new System.Drawing.Point(118, 10);
            this.txtPersonIndex.Name = "txtPersonIndex";
            this.txtPersonIndex.Size = new System.Drawing.Size(119, 20);
            this.txtPersonIndex.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Person Index Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Make";
            // 
            // txtMake
            // 
            this.txtMake.Location = new System.Drawing.Point(118, 36);
            this.txtMake.Name = "txtMake";
            this.txtMake.Size = new System.Drawing.Size(119, 20);
            this.txtMake.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Model";
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(118, 62);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(119, 20);
            this.txtModel.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Year";
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(118, 88);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(119, 20);
            this.txtYear.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Price";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(118, 114);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(119, 20);
            this.txtPrice.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Vin";
            // 
            // txtVin
            // 
            this.txtVin.Location = new System.Drawing.Point(118, 140);
            this.txtVin.Name = "txtVin";
            this.txtVin.Size = new System.Drawing.Size(119, 20);
            this.txtVin.TabIndex = 10;
            // 
            // btnAddACar
            // 
            this.btnAddACar.Location = new System.Drawing.Point(4, 166);
            this.btnAddACar.Name = "btnAddACar";
            this.btnAddACar.Size = new System.Drawing.Size(233, 31);
            this.btnAddACar.TabIndex = 12;
            this.btnAddACar.Text = "Add A Car";
            this.btnAddACar.UseVisualStyleBackColor = true;
            this.btnAddACar.Click += new System.EventHandler(this.btnAddACar_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Vin";
            // 
            // txtVinPriceUpdate
            // 
            this.txtVinPriceUpdate.Location = new System.Drawing.Point(40, 32);
            this.txtVinPriceUpdate.Name = "txtVinPriceUpdate";
            this.txtVinPriceUpdate.Size = new System.Drawing.Size(104, 20);
            this.txtVinPriceUpdate.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Price";
            // 
            // txtPriceUpdate
            // 
            this.txtPriceUpdate.Location = new System.Drawing.Point(40, 6);
            this.txtPriceUpdate.Name = "txtPriceUpdate";
            this.txtPriceUpdate.Size = new System.Drawing.Size(104, 20);
            this.txtPriceUpdate.TabIndex = 13;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnUpdatePrice);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtVinPriceUpdate);
            this.panel2.Controls.Add(this.txtPriceUpdate);
            this.panel2.Location = new System.Drawing.Point(260, 204);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(147, 103);
            this.panel2.TabIndex = 17;
            // 
            // btnUpdatePrice
            // 
            this.btnUpdatePrice.Location = new System.Drawing.Point(6, 58);
            this.btnUpdatePrice.Name = "btnUpdatePrice";
            this.btnUpdatePrice.Size = new System.Drawing.Size(138, 42);
            this.btnUpdatePrice.TabIndex = 17;
            this.btnUpdatePrice.Text = "Update Car Price";
            this.btnUpdatePrice.UseVisualStyleBackColor = true;
            this.btnUpdatePrice.Click += new System.EventHandler(this.btnUpdatePrice_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnSellCar);
            this.panel3.Controls.Add(this.txtVinSellCar);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(260, 311);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(147, 64);
            this.panel3.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(22, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Vin";
            // 
            // txtVinSellCar
            // 
            this.txtVinSellCar.Location = new System.Drawing.Point(32, 1);
            this.txtVinSellCar.Name = "txtVinSellCar";
            this.txtVinSellCar.Size = new System.Drawing.Size(112, 20);
            this.txtVinSellCar.TabIndex = 19;
            // 
            // btnSellCar
            // 
            this.btnSellCar.Location = new System.Drawing.Point(4, 27);
            this.btnSellCar.Name = "btnSellCar";
            this.btnSellCar.Size = new System.Drawing.Size(140, 29);
            this.btnSellCar.TabIndex = 20;
            this.btnSellCar.Text = "Sell Car";
            this.btnSellCar.UseVisualStyleBackColor = true;
            this.btnSellCar.Click += new System.EventHandler(this.btnSellCar_Click);
            // 
            // frmVehicalTester
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 415);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnDisplayPeopleAndCars);
            this.Controls.Add(this.rchtxtVehicalList);
            this.Name = "frmVehicalTester";
            this.Text = "Vehical Tester";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtVehicalList;
        private System.Windows.Forms.Button btnDisplayPeopleAndCars;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAddACar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtVin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMake;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPersonIndex;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtVinPriceUpdate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtPriceUpdate;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnUpdatePrice;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnSellCar;
        private System.Windows.Forms.TextBox txtVinSellCar;
        private System.Windows.Forms.Label label9;
    }
}

