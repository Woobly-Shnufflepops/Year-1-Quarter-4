﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IAgeSpace
{
    // Question 13
    public interface IAnimal
    {
        void Voice();
        void Draw();
    }
}
